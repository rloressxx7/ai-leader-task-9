import type { EngineConfig } from "./config.js";
import type { LogNotification } from "./types.js";
import { EventDetector } from "./detector.js";
import { JupiterExecutor } from "./jupiter.js";
import { errorMessage, log } from "./logger.js";
import { LogMonitor } from "./rpc.js";
import { PriorityFeeOracle, RiskManager, WalletManager } from "./risk.js";

const MAX_QUEUE_SIZE = 256;

export class TradingEngine {
  private readonly queue: LogNotification[] = [];
  private readonly seenSignatures = new Map<string, number>();
  private processing = false;
  private readonly exiting = new Set<string>();

  constructor(
    private readonly config: EngineConfig,
    private readonly monitor: LogMonitor,
    private readonly detector: EventDetector,
    private readonly executor: JupiterExecutor,
    private readonly risk: RiskManager,
    private readonly wallet: WalletManager,
    private readonly fees: PriorityFeeOracle
  ) {}

  async run(signal: AbortSignal): Promise<void> {
    log("info", "trading engine started", {
      dryRun: this.config.dryRun,
      inputMint: this.config.inputMint,
      buyAmountRaw: this.config.buyAmountRaw,
      programs: this.config.eventRules.length,
      riskProfile: this.config.riskProfile,
      slippageBps: this.config.slippageBps,
      sellSlippageBps: this.config.sellSlippageBps,
      priorityFeeMode: this.config.priorityFeeMode,
      takeProfitBps: this.config.takeProfitBps,
      stopLossBps: this.config.stopLossBps,
      trailingStopBps: this.config.trailingStopBps,
      maxHoldSeconds: this.config.maxHoldSeconds,
      wallet: this.wallet.walletAddress
    });
    await Promise.all([
      this.monitor.run((notification) => this.enqueue(notification, signal), signal),
      this.watchPositions(signal)
    ]);
  }

  private enqueue(notification: LogNotification, signal: AbortSignal): void {
    if (!this.detector.matches(notification)) return;
    this.pruneSeen();
    if (this.seenSignatures.has(notification.signature)) return;
    this.seenSignatures.set(notification.signature, Date.now());
    if (this.queue.length >= MAX_QUEUE_SIZE) {
      log("warn", "event queue full; dropping notification", { signature: notification.signature });
      return;
    }
    this.queue.push(notification);
    if (!this.processing) void this.drain(signal);
  }

  private async drain(signal: AbortSignal): Promise<void> {
    this.processing = true;
    try {
      while (this.queue.length > 0 && !signal.aborted) {
        const notification = this.queue.shift();
        if (!notification) continue;
        try {
          await this.process(notification, signal);
        } catch (error) {
          log("error", "event processing failed", {
            signature: notification.signature,
            error: errorMessage(error).slice(0, 1_000)
          });
        }
      }
    } finally {
      this.processing = false;
    }
  }

  private async process(notification: LogNotification, signal: AbortSignal): Promise<void> {
    const event = await this.detector.detect(notification, signal);
    if (!event) {
      log("debug", "matching transaction did not resolve to one safe token candidate", {
        signature: notification.signature
      });
      return;
    }
    log("info", "launch/liquidity event detected", {
      type: event.type,
      source: event.source,
      signature: event.signature,
      tokenMint: event.tokenMint,
      quoteBalanceRaw: event.quoteBalanceRaw
    });

    const rejection = this.risk.entryRejection(event.tokenMint, event.blockTime);
    if (rejection) {
      log("warn", "event rejected by risk controls", { signature: event.signature, reason: rejection });
      return;
    }

    const priorityFeeLamports = await this.fees.current(signal);
    const size = await this.wallet.sizeBuy(priorityFeeLamports, signal);
    const sizeRejection = "rejection" in size ? size.rejection : this.risk.spendRejection(size.amountRaw);
    if (sizeRejection || !("amountRaw" in size)) {
      log("warn", "event rejected by wallet controls", { signature: event.signature, reason: sizeRejection });
      return;
    }

    const result = await this.executor.execute(event.tokenMint, signal, { amountRaw: size.amountRaw, priorityFeeLamports });
    // Live: trust the chain. Dry-run (or RPC lag): assume the worst case the quote guaranteed.
    const held = await this.wallet.heldAmount(event.tokenMint, signal).catch(() => null)
      ?? BigInt(this.config.dryRun ? result.quote.outAmount : result.quote.otherAmountThreshold);
    this.risk.recordEntry({
      tokenMint: event.tokenMint,
      entryInRaw: size.amountRaw,
      amountRaw: held,
      openedAt: Date.now(),
      peakValueRaw: size.amountRaw,
      ...(result.signature ? { entrySignature: result.signature } : {})
    });
    log("info", result.status === "dry_run" ? "swap simulated" : "swap confirmed", {
      eventSignature: event.signature,
      swapSignature: result.signature,
      tokenMint: event.tokenMint,
      inAmount: result.quote.inAmount,
      outAmount: result.quote.outAmount,
      heldAmount: held,
      priceImpactPct: result.quote.priceImpactPct,
      priorityFeeLamports,
      tradesThisSession: this.risk.tradeCount
    });
  }

  private async watchPositions(signal: AbortSignal): Promise<void> {
    while (!signal.aborted) {
      await delay(this.config.positionPollMs, signal);
      if (signal.aborted) return;
      await Promise.all(this.risk.positions().map((position) => this.checkPosition(position.tokenMint, signal)));
    }
  }

  async checkPosition(tokenMint: string, signal: AbortSignal): Promise<void> {
    if (this.exiting.has(tokenMint)) return;
    const position = this.risk.positions().find((open) => open.tokenMint === tokenMint);
    if (!position) return;
    this.exiting.add(tokenMint);
    try {
      const quote = await this.executor.getSellQuote(tokenMint, position.amountRaw, signal);
      const valueRaw = BigInt(quote.outAmount);
      const reason = this.risk.mark(tokenMint, valueRaw);
      if (!reason) return;
      const priorityFeeLamports = await this.fees.current(signal);
      const result = await this.executor.sell(tokenMint, position.amountRaw, signal, { quote, priorityFeeLamports });
      this.risk.close(tokenMint);
      log("info", result.status === "dry_run" ? "exit simulated" : "exit confirmed", {
        tokenMint,
        reason,
        swapSignature: result.signature,
        entryInRaw: position.entryInRaw,
        exitOutRaw: result.quote.outAmount,
        priorityFeeLamports
      });
    } catch (error) {
      if (!signal.aborted) log("error", "position check failed", { tokenMint, error: errorMessage(error).slice(0, 1_000) });
    } finally {
      this.exiting.delete(tokenMint);
    }
  }

  private pruneSeen(): void {
    const cutoff = Date.now() - 10 * 60_000;
    for (const [signature, seenAt] of this.seenSignatures) {
      if (seenAt < cutoff) this.seenSignatures.delete(signature);
    }
  }
}

function delay(ms: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve) => {
    const timer = setTimeout(resolve, ms);
    signal.addEventListener("abort", () => {
      clearTimeout(timer);
      resolve();
    }, { once: true });
  });
}
