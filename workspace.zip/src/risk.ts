import type { EngineConfig } from "./config.js";
import { WSOL_MINT } from "./config.js";
import { errorMessage, log } from "./logger.js";
import type { SolanaRpc } from "./rpc.js";

/** Network base fee per signature; Jupiter swaps built here need one signature. */
export const BASE_FEE_LAMPORTS = 5_000n;
const FEE_CACHE_MS = 2_000;

export type ExitReason = "take_profit" | "stop_loss" | "trailing_stop" | "max_hold";

export interface Position {
  tokenMint: string;
  /** Raw input-mint amount spent on entry. */
  entryInRaw: bigint;
  /** Raw token amount held. */
  amountRaw: bigint;
  openedAt: number;
  /** Highest observed exit value (input-mint raw units), used by the trailing stop. */
  peakValueRaw: bigint;
  entrySignature?: string;
}

/** Change from `from` to `to` in basis points, rounded toward zero. */
export function changeBps(from: bigint, to: bigint): number {
  if (from <= 0n) throw new Error("Reference value must be positive");
  return Number(((to - from) * 10_000n) / from);
}

/** Decide whether an open position should be closed at its current quoted exit value. */
export function evaluateExit(
  position: Position,
  currentValueRaw: bigint,
  now: number,
  config: Pick<EngineConfig, "takeProfitBps" | "stopLossBps" | "trailingStopBps" | "maxHoldSeconds">
): ExitReason | null {
  const pnlBps = changeBps(position.entryInRaw, currentValueRaw);
  if (config.stopLossBps > 0 && pnlBps <= -config.stopLossBps) return "stop_loss";
  if (config.takeProfitBps > 0 && pnlBps >= config.takeProfitBps) return "take_profit";
  const peak = currentValueRaw > position.peakValueRaw ? currentValueRaw : position.peakValueRaw;
  // Only trail once the position has been in profit, so the trailing stop never
  // pre-empts the hard stop-loss on an immediately losing entry.
  if (config.trailingStopBps > 0 && peak > position.entryInRaw && changeBps(peak, currentValueRaw) <= -config.trailingStopBps) {
    return "trailing_stop";
  }
  if (config.maxHoldSeconds > 0 && now - position.openedAt >= config.maxHoldSeconds * 1_000) return "max_hold";
  return null;
}

/**
 * Convert recent micro-lamports-per-CU samples into a total priority fee in
 * lamports at the configured percentile, clamped to [floor, max].
 */
export function selectPriorityFee(
  samples: number[],
  config: Pick<EngineConfig, "priorityFeeLamports" | "priorityFeeMaxLamports" | "priorityFeePercentile" | "priorityFeeComputeUnits">
): number {
  const valid = samples.filter((sample) => Number.isFinite(sample) && sample >= 0).sort((a, b) => a - b);
  if (valid.length === 0) return config.priorityFeeLamports;
  const index = Math.min(valid.length - 1, Math.max(0, Math.ceil((config.priorityFeePercentile / 100) * valid.length) - 1));
  const lamports = Math.ceil((valid[index]! * config.priorityFeeComputeUnits) / 1_000_000);
  return Math.min(config.priorityFeeMaxLamports, Math.max(config.priorityFeeLamports, lamports));
}

export class PriorityFeeOracle {
  private cached?: { lamports: number; at: number };

  constructor(private readonly rpc: Pick<SolanaRpc, "getRecentPrioritizationFees">, private readonly config: EngineConfig) {}

  async current(signal?: AbortSignal): Promise<number> {
    if (this.config.priorityFeeMode === "fixed") return this.config.priorityFeeLamports;
    if (this.cached && Date.now() - this.cached.at < FEE_CACHE_MS) return this.cached.lamports;
    try {
      const lamports = selectPriorityFee(await this.rpc.getRecentPrioritizationFees([], signal), this.config);
      this.cached = { lamports, at: Date.now() };
      return lamports;
    } catch (error) {
      if (signal?.aborted) throw error;
      log("warn", "priority fee lookup failed; using floor", { error: errorMessage(error) });
      return this.config.priorityFeeLamports;
    }
  }
}

/**
 * Wallet management: sizes buys from the live balance while always keeping a
 * SOL reserve for fees, rent, and exits. Dry-run has no wallet, so it uses the
 * configured amount unchanged.
 */
export class WalletManager {
  constructor(
    private readonly rpc: Pick<SolanaRpc, "getBalance" | "getTokenBalance">,
    private readonly config: EngineConfig,
    private readonly address?: string
  ) {}

  get walletAddress(): string | undefined {
    return this.address;
  }

  async sizeBuy(priorityFeeLamports: number, signal?: AbortSignal): Promise<{ amountRaw: bigint } | { rejection: string }> {
    if (!this.address) return { amountRaw: this.config.buyAmountRaw };
    const fees = BASE_FEE_LAMPORTS + BigInt(priorityFeeLamports);
    const sol = await this.rpc.getBalance(this.address, signal);
    const solAfterFees = sol - this.config.minSolReserveLamports - fees;
    if (solAfterFees < 0n) return { rejection: "SOL balance is below reserve plus fees" };

    const available = this.config.inputMint === WSOL_MINT
      ? solAfterFees
      : await this.rpc.getTokenBalance(this.address, this.config.inputMint, signal);
    const cap = (available * BigInt(this.config.maxBalanceFractionBps)) / 10_000n;
    const amountRaw = cap < this.config.buyAmountRaw ? cap : this.config.buyAmountRaw;
    if (amountRaw < this.config.minBuyAmountRaw) return { rejection: "wallet balance too low for minimum buy size" };
    return { amountRaw };
  }

  /** Actual held amount after a live buy; null in dry-run or when the RPC has not indexed it yet. */
  async heldAmount(tokenMint: string, signal?: AbortSignal): Promise<bigint | null> {
    if (!this.address) return null;
    const amount = await this.rpc.getTokenBalance(this.address, tokenMint, signal);
    return amount > 0n ? amount : null;
  }
}

/** Session-level entry limits and open-position book-keeping. */
export class RiskManager {
  private readonly open = new Map<string, Position>();
  private trades = 0;
  private spent = 0n;
  private lastTradeAt = 0;

  constructor(private readonly config: EngineConfig) {}

  entryRejection(tokenMint: string, blockTime: number | null, now = Date.now()): string | null {
    if (this.config.denyMints.has(tokenMint)) return "mint is denied";
    if (this.config.allowMints.size > 0 && !this.config.allowMints.has(tokenMint)) return "mint is not allowed";
    if (blockTime !== null && now / 1_000 - blockTime > this.config.maxEventAgeSeconds) return "event is stale";
    if (this.open.has(tokenMint)) return "position already open";
    if (this.open.size >= this.config.maxOpenPositions) return "open position limit reached";
    if (this.trades >= this.config.maxTradesPerSession) return "session trade limit reached";
    if (now - this.lastTradeAt < this.config.tradeCooldownMs) return "trade cooldown is active";
    return null;
  }

  spendRejection(amountRaw: bigint): string | null {
    return this.spent + amountRaw > this.config.maxSessionSpendRaw ? "session spend limit reached" : null;
  }

  recordEntry(position: Position): void {
    this.trades += 1;
    this.spent += position.entryInRaw;
    this.lastTradeAt = position.openedAt;
    this.open.set(position.tokenMint, position);
  }

  /** Update the trailing-stop peak and return the exit decision for this mark. */
  mark(tokenMint: string, valueRaw: bigint, now = Date.now()): ExitReason | null {
    const position = this.open.get(tokenMint);
    if (!position) return null;
    const reason = evaluateExit(position, valueRaw, now, this.config);
    if (valueRaw > position.peakValueRaw) position.peakValueRaw = valueRaw;
    return reason;
  }

  close(tokenMint: string): Position | undefined {
    const position = this.open.get(tokenMint);
    this.open.delete(tokenMint);
    return position;
  }

  positions(): Position[] {
    return [...this.open.values()];
  }

  get tradeCount(): number {
    return this.trades;
  }
}
