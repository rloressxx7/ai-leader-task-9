import type { EngineConfig } from "./config.js";
import type { LaunchEvent, LogNotification } from "./types.js";
import type { SolanaRpc } from "./rpc.js";

type UnknownRecord = Record<string, unknown>;

function record(value: unknown): UnknownRecord | undefined {
  return typeof value === "object" && value !== null ? value as UnknownRecord : undefined;
}

function array(value: unknown): unknown[] {
  return Array.isArray(value) ? value : [];
}

function parsedInstructions(transaction: UnknownRecord): UnknownRecord[] {
  const tx = record(transaction.transaction);
  const message = record(tx?.message);
  const topLevel = array(message?.instructions).map(record).filter((item): item is UnknownRecord => !!item);
  const meta = record(transaction.meta);
  const inner = array(meta?.innerInstructions).flatMap((group) => {
    const entry = record(group);
    return array(entry?.instructions).map(record).filter((item): item is UnknownRecord => !!item);
  });
  return [...topLevel, ...inner];
}

function initializedMints(transaction: UnknownRecord): Set<string> {
  const result = new Set<string>();
  for (const instruction of parsedInstructions(transaction)) {
    const parsed = record(instruction.parsed);
    if (!["initializeMint", "initializeMint2"].includes(String(parsed?.type))) continue;
    const info = record(parsed?.info);
    if (typeof info?.mint === "string") result.add(info.mint);
  }
  return result;
}

interface TokenBalance {
  mint: string;
  amount: bigint;
}

function tokenBalances(transaction: UnknownRecord): TokenBalance[] {
  const meta = record(transaction.meta);
  const balances: TokenBalance[] = [];
  for (const raw of array(meta?.postTokenBalances)) {
    const balance = record(raw);
    const tokenAmount = record(balance?.uiTokenAmount);
    if (typeof balance?.mint !== "string" || typeof tokenAmount?.amount !== "string") continue;
    try {
      balances.push({ mint: balance.mint, amount: BigInt(tokenAmount.amount) });
    } catch {
      // Ignore malformed RPC fields instead of guessing a value.
    }
  }
  return balances;
}

export class EventDetector {
  constructor(private readonly rpc: SolanaRpc, private readonly config: EngineConfig) {}

  matches(notification: LogNotification): boolean {
    if (notification.err !== null) return false;
    const rule = this.config.eventRules.find((candidate) => candidate.programId === notification.programId);
    if (!rule) return false;
    const logs = notification.logs.map((line) => line.toLowerCase());
    return rule.logPatterns.some((rawPattern) => {
      const pattern = rawPattern.toLowerCase();
      return logs.some((line) => pattern.startsWith("instruction:")
        ? line.replace(/^program log:\s*/, "").trim() === pattern
        : line.includes(pattern));
    });
  }

  async detect(notification: LogNotification, signal?: AbortSignal): Promise<LaunchEvent | null> {
    if (!this.matches(notification)) return null;
    const rule = this.config.eventRules.find((candidate) => candidate.programId === notification.programId);
    if (!rule) return null;

    // A confirmed log can arrive just before getTransaction is populated on some RPC nodes.
    let transaction: UnknownRecord | null = null;
    for (let attempt = 0; attempt < 5 && !transaction; attempt += 1) {
      transaction = await this.rpc.getTransaction(notification.signature, signal);
      if (!transaction && attempt < 4) await new Promise((resolve) => setTimeout(resolve, 250 * (attempt + 1)));
    }
    if (!transaction) return null;

    const balances = tokenBalances(transaction);
    const postMints = new Set(balances.map(({ mint }) => mint));
    const initialized = initializedMints(transaction);
    const unknownPostMints = [...postMints].filter((mint) => !this.config.knownQuoteMints.has(mint));
    const initializedCandidates = [...initialized].filter((mint) => !this.config.knownQuoteMints.has(mint));
    let candidates = initializedCandidates.length > 0 ? initializedCandidates : unknownPostMints;

    if (this.config.allowMints.size > 0) candidates = candidates.filter((mint) => this.config.allowMints.has(mint));
    candidates = [...new Set(candidates)].filter((mint) => !this.config.denyMints.has(mint));

    // Never guess when a pool transaction contains multiple non-quote assets.
    if (candidates.length !== 1) return null;
    const tokenMint = candidates[0];
    if (!tokenMint) return null;

    const quoteAmounts = balances.filter(({ mint }) => mint === this.config.inputMint).map(({ amount }) => amount);
    const quoteBalanceRaw = quoteAmounts.length > 0
      ? quoteAmounts.reduce((largest, amount) => amount > largest ? amount : largest, 0n)
      : null;
    const rawBlockTime = transaction.blockTime;

    return {
      type: rule.eventType,
      source: rule.name,
      programId: rule.programId,
      signature: notification.signature,
      slot: notification.slot,
      observedAt: Date.now(),
      blockTime: typeof rawBlockTime === "number" ? rawBlockTime : null,
      tokenMint,
      quoteMint: this.config.inputMint,
      quoteBalanceRaw
    };
  }
}
