export type EventType = "token_launch" | "liquidity_added";

export interface EventRule {
  name: string;
  programId: string;
  eventType: EventType;
  logPatterns: string[];
}

export interface LogNotification {
  programId: string;
  signature: string;
  slot: number;
  err: unknown | null;
  logs: string[];
}

export interface LaunchEvent {
  type: EventType;
  source: string;
  programId: string;
  signature: string;
  slot: number;
  observedAt: number;
  blockTime: number | null;
  tokenMint: string;
  quoteMint: string;
  quoteBalanceRaw: bigint | null;
}

export interface JupiterQuote {
  inputMint: string;
  inAmount: string;
  outputMint: string;
  outAmount: string;
  otherAmountThreshold: string;
  swapMode: string;
  slippageBps: number;
  priceImpactPct: string;
  routePlan: unknown[];
  [key: string]: unknown;
}

export interface SwapResult {
  status: "dry_run" | "submitted";
  quote: JupiterQuote;
  signature?: string;
}
