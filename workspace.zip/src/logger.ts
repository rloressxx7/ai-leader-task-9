export type LogLevel = "debug" | "info" | "warn" | "error";

export function log(level: LogLevel, message: string, fields: Record<string, unknown> = {}): void {
  const normalized = Object.fromEntries(
    Object.entries(fields).map(([key, value]) => [key, typeof value === "bigint" ? value.toString() : value])
  );
  process.stdout.write(`${JSON.stringify({ time: new Date().toISOString(), level, message, ...normalized })}\n`);
}

export function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
