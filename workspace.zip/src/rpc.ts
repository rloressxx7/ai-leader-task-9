import type { EventRule, LogNotification } from "./types.js";
import { errorMessage, log } from "./logger.js";

interface JsonRpcResponse<T> {
  result?: T;
  error?: { code: number; message: string; data?: unknown };
}

export class SolanaRpc {
  private requestId = 1;

  constructor(
    private readonly httpUrl: string,
    private readonly commitment: "processed" | "confirmed" | "finalized"
  ) {}

  async call<T>(method: string, params: unknown[], signal?: AbortSignal): Promise<T> {
    const response = await fetch(this.httpUrl, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: this.requestId++, method, params }),
      ...(signal ? { signal } : {})
    });
    if (!response.ok) throw new Error(`RPC ${method} returned HTTP ${response.status}`);
    const body = await response.json() as JsonRpcResponse<T>;
    if (body.error) throw new Error(`RPC ${method} failed (${body.error.code}): ${body.error.message}`);
    if (!("result" in body)) throw new Error(`RPC ${method} returned no result`);
    return body.result as T;
  }

  async getTransaction(signature: string, signal?: AbortSignal): Promise<Record<string, unknown> | null> {
    return this.call("getTransaction", [signature, {
      commitment: this.commitment === "processed" ? "confirmed" : this.commitment,
      encoding: "jsonParsed",
      maxSupportedTransactionVersion: 0
    }], signal);
  }

  async getBalance(address: string, signal?: AbortSignal): Promise<bigint> {
    const result = await this.call<{ value: number }>("getBalance", [address, { commitment: this.commitment }], signal);
    return BigInt(result.value);
  }

  /** Sum of all SPL token accounts the owner holds for a mint, in raw units. */
  async getTokenBalance(owner: string, mint: string, signal?: AbortSignal): Promise<bigint> {
    const result = await this.call<{ value: Array<{ account: { data: { parsed?: { info?: { tokenAmount?: { amount?: string } } } } } }> }>(
      "getTokenAccountsByOwner", [owner, { mint }, { encoding: "jsonParsed", commitment: this.commitment }], signal
    );
    return result.value.reduce((total, entry) => total + BigInt(entry.account.data.parsed?.info?.tokenAmount?.amount ?? "0"), 0n);
  }

  /** Recent per-slot prioritization fees in micro-lamports per compute unit. */
  async getRecentPrioritizationFees(accounts: string[] = [], signal?: AbortSignal): Promise<number[]> {
    const result = await this.call<Array<{ slot: number; prioritizationFee: number }>>(
      "getRecentPrioritizationFees", accounts.length > 0 ? [accounts] : [], signal
    );
    return result.map((sample) => sample.prioritizationFee);
  }

  async sendTransaction(serializedBase64: string, signal?: AbortSignal): Promise<string> {
    return this.call("sendTransaction", [serializedBase64, {
      encoding: "base64",
      skipPreflight: false,
      preflightCommitment: "confirmed",
      maxRetries: 2
    }], signal);
  }

  async confirmSignature(signature: string, timeoutMs: number, signal?: AbortSignal): Promise<void> {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (signal?.aborted) throw signal.reason ?? new Error("Aborted");
      const statuses = await this.call<{ value: Array<{ err: unknown; confirmationStatus?: string } | null> }>(
        "getSignatureStatuses", [[signature], { searchTransactionHistory: true }], signal
      );
      const status = statuses.value[0];
      if (status?.err) throw new Error(`Transaction ${signature} failed: ${JSON.stringify(status.err)}`);
      if (status && ["confirmed", "finalized"].includes(status.confirmationStatus ?? "")) return;
      await abortableDelay(1_000, signal);
    }
    throw new Error(`Confirmation timed out for ${signature}`);
  }
}

function abortableDelay(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms);
    if (signal) signal.addEventListener("abort", () => {
      clearTimeout(timer);
      reject(signal.reason ?? new Error("Aborted"));
    }, { once: true });
  });
}

interface SocketMessage {
  id?: number;
  result?: number;
  error?: { message: string };
  method?: string;
  params?: {
    subscription: number;
    result: {
      context: { slot: number };
      value: { signature: string; err: unknown | null; logs: string[] };
    };
  };
}

export class LogMonitor {
  constructor(
    private readonly wsUrl: string,
    private readonly commitment: "processed" | "confirmed" | "finalized",
    private readonly rules: EventRule[]
  ) {}

  async run(handler: (notification: LogNotification) => void, signal: AbortSignal): Promise<void> {
    let attempt = 0;
    while (!signal.aborted) {
      try {
        await this.connect(handler, signal);
        attempt = 0;
      } catch (error) {
        if (signal.aborted) return;
        attempt += 1;
        const waitMs = Math.min(30_000, 500 * 2 ** Math.min(attempt, 6)) + Math.floor(Math.random() * 250);
        log("warn", "websocket disconnected; reconnecting", { error: errorMessage(error), waitMs, attempt });
        await abortableDelay(waitMs, signal).catch(() => undefined);
      }
    }
  }

  private connect(handler: (notification: LogNotification) => void, signal: AbortSignal): Promise<void> {
    return new Promise((resolve, reject) => {
      const socket = new WebSocket(this.wsUrl);
      const pending = new Map<number, string>();
      const subscriptions = new Map<number, string>();
      let settled = false;

      const finish = (error?: Error) => {
        if (settled) return;
        settled = true;
        signal.removeEventListener("abort", onAbort);
        if (error) reject(error); else resolve();
      };
      const onAbort = () => { socket.close(); finish(); };
      signal.addEventListener("abort", onAbort, { once: true });

      socket.addEventListener("open", () => {
        this.rules.forEach((rule, index) => {
          const id = index + 1;
          pending.set(id, rule.programId);
          socket.send(JSON.stringify({
            jsonrpc: "2.0", id, method: "logsSubscribe",
            params: [{ mentions: [rule.programId] }, { commitment: this.commitment }]
          }));
        });
      });

      socket.addEventListener("message", (event) => {
        try {
          const message = JSON.parse(String(event.data)) as SocketMessage;
          if (message.id !== undefined) {
            const programId = pending.get(message.id);
            if (message.error) throw new Error(`logsSubscribe failed: ${message.error.message}`);
            if (programId && message.result !== undefined) {
              subscriptions.set(message.result, programId);
              pending.delete(message.id);
              log("info", "subscribed to program logs", { programId, subscription: message.result });
            }
            return;
          }
          if (message.method !== "logsNotification" || !message.params) return;
          const programId = subscriptions.get(message.params.subscription);
          if (!programId) return;
          const { context, value } = message.params.result;
          handler({ programId, signature: value.signature, slot: context.slot, err: value.err, logs: value.logs });
        } catch (error) {
          log("warn", "ignored malformed websocket message", { error: errorMessage(error) });
        }
      });
      socket.addEventListener("error", () => finish(new Error("WebSocket transport error")));
      socket.addEventListener("close", () => finish(signal.aborted ? undefined : new Error("WebSocket closed")));
    });
  }
}
