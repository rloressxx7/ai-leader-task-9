import "dotenv/config";
import { loadConfig } from "./config.js";
import { EventDetector } from "./detector.js";
import { TradingEngine } from "./engine.js";
import { JupiterExecutor } from "./jupiter.js";
import { errorMessage, log } from "./logger.js";
import { PriorityFeeOracle, RiskManager, WalletManager } from "./risk.js";
import { LogMonitor, SolanaRpc } from "./rpc.js";

async function main(): Promise<void> {
  const config = loadConfig();
  const rpc = new SolanaRpc(config.rpcHttpUrl, config.commitment);
  const monitor = new LogMonitor(config.rpcWsUrl, config.commitment, config.eventRules);
  const detector = new EventDetector(rpc, config);
  const executor = new JupiterExecutor(rpc, config);
  const wallet = new WalletManager(rpc, config, executor.walletAddress);
  const fees = new PriorityFeeOracle(rpc, config);
  const engine = new TradingEngine(config, monitor, detector, executor, new RiskManager(config), wallet, fees);
  const controller = new AbortController();

  const stop = (signal: string) => {
    log("info", "shutdown requested", { signal });
    controller.abort(new Error(signal));
  };
  process.once("SIGINT", () => stop("SIGINT"));
  process.once("SIGTERM", () => stop("SIGTERM"));

  await engine.run(controller.signal);
}

main().catch((error) => {
  log("error", "fatal engine error", { error: errorMessage(error) });
  process.exitCode = 1;
});
