# Solana launch trading engine

An event-driven TypeScript engine that watches Solana program logs for new Raydium pools and LaunchLab token initializations, enriches matching transactions through JSON-RPC, identifies a single non-quote mint, and obtains/executes an aggregated swap through Jupiter.

The engine is intentionally **dry-run by default**. In dry-run mode it monitors live events and requests real quotes, but never loads a wallet, signs, or submits a transaction.

## What it monitors

Built-in rules cover:

- Raydium CPMM pool initialization
- Raydium AMM v4 `initialize2`
- Raydium CLMM pool creation
- Raydium LaunchLab initialization

Solana `logsSubscribe` accepts only one mentioned address per subscription, so the monitor creates one subscription per program over a shared WebSocket. It reconnects with bounded exponential backoff. Matching signatures are fetched with `getTransaction`, including a short retry for RPC indexing lag.

Event rules can be replaced without code changes using `EVENT_RULES_JSON`. Detection refuses failed transactions and ambiguous transactions containing more than one unknown, non-quote mint; it does not guess which asset to buy.

## Setup

Requires Node.js 22 or newer.

```sh
npm install
npm run check
npm test
copy .env.example .env
npm run dev
```

For a production build:

```sh
npm run build
npm start
```

Use a low-latency Solana RPC provider and set both `SOLANA_RPC_HTTP` and `SOLANA_RPC_WS`. Public endpoints are rate-limited and are not suitable for latency-sensitive execution.

## Live execution

Review all limits in `.env.example`, fund a dedicated low-value wallet, then set:

```dotenv
DRY_RUN=false
SOLANA_PRIVATE_KEY=[...64 secret-key bytes...]
```

The private key can alternatively be base58 encoded. It is read only for live mode and is never logged. `.env` is ignored by git.

Before a live trade the engine enforces:

- optional mint allow/deny lists;
- maximum event age;
- fixed raw input amount and total session spend;
- maximum trades per process, maximum open positions, and a cooldown;
- maximum Jupiter-reported price impact and capped buy/sell slippage;
- wallet SOL reserve and balance-fraction sizing;
- take-profit, stop-loss, trailing-stop and max-hold exits;
- preflight simulation and confirmed/finalized status polling.

`BUY_AMOUNT_RAW` is in the input token's smallest unit (for WSOL, 10,000,000 is 0.01 SOL). Session limits reset when the process restarts. Jupiter's route may use Raydium or another supported Solana DEX; `restrictIntermediateTokens` is enabled to reduce route complexity.

## Risk management and configuration

`src/risk.ts` holds all risk logic; `src/config.ts` loads it from the environment.

| Area | Settings | Behaviour |
| --- | --- | --- |
| Profile | `RISK_PROFILE` | `conservative` (default), `balanced`, `aggressive` seed the values below. Any explicitly set variable overrides the profile. |
| Slippage | `SLIPPAGE_BPS`, `SELL_SLIPPAGE_BPS`, `MAX_SLIPPAGE_BPS` | Separate buy/sell tolerances; both must be ≤ the hard cap, which is re-checked before every quote. Quotes that come back with wider slippage are rejected. |
| Priority fee | `PRIORITY_FEE_MODE`, `PRIORITY_FEE_LAMPORTS`, `PRIORITY_FEE_MAX_LAMPORTS`, `PRIORITY_FEE_PERCENTILE`, `PRIORITY_FEE_COMPUTE_UNITS` | `fixed` sends the configured lamports. `dynamic` takes a percentile of `getRecentPrioritizationFees` (µ-lamports/CU) × compute units, clamped to floor/cap, cached 2 s, and falls back to the floor on RPC errors. |
| Exits | `TAKE_PROFIT_PCT`, `STOP_LOSS_PCT`, `TRAILING_STOP_PCT`, `MAX_HOLD_SECONDS`, `POSITION_POLL_MS` | Open positions are re-quoted (token → `INPUT_MINT`) on each poll. Stop-loss is checked first; the trailing stop only arms once the position has been in profit. Exit quotes are not price-impact capped so a stop-loss can still leave a thin pool. |
| Wallet | `MIN_SOL_RESERVE_LAMPORTS`, `MAX_BALANCE_FRACTION_PCT`, `MIN_BUY_AMOUNT_RAW`, `MAX_OPEN_POSITIONS` | Live mode reads the wallet balance before each buy, keeps the SOL reserve plus fees untouched, and caps the buy at a fraction of what is spendable (SOL, or the `INPUT_MINT` token balance). Buys smaller than `MIN_BUY_AMOUNT_RAW` are skipped. Held amounts are read back from chain after a live buy. |

Profile presets:

| | conservative | balanced | aggressive |
| --- | --- | --- | --- |
| Buy / sell / cap slippage (bps) | 300 / 500 / 1000 | 500 / 800 / 1500 | 1000 / 1500 / 2500 |
| Priority fee | fixed 100k | dynamic p75, 100k–2M | dynamic p90, 200k–5M |
| TP / SL / trailing | 50% / 20% / off | 100% / 25% / 15% | 200% / 35% / 20% |
| Max hold | 30 min | 60 min | 120 min |

The presets are generic starting points, **not** a measured copy of any particular wallet. The wallet-analysis step has not yet produced quantitative figures (typical entry size, hold time, exit multiples, fees paid). Once it does, set the matching variables directly (e.g. `BUY_AMOUNT_RAW`, `TAKE_PROFIT_PCT`, `MAX_HOLD_SECONDS`, `PRIORITY_FEE_PERCENTILE`) instead of adding a new preset.

In dry-run, positions are opened from the quoted `outAmount` and exits are logged as `exit simulated`, so exit rules can be validated without a wallet. Round-trip quotes include both swaps' fees and impact, so a fresh dry-run position will normally show a small immediate loss.

## Custom event rules

Set a compact JSON array. Every rule opens a program subscription and matches at least one case-insensitive log fragment:

```json
[
  {
    "name": "my-launchpad",
    "programId": "PROGRAM_PUBLIC_KEY",
    "eventType": "token_launch",
    "logPatterns": ["Instruction: Initialize"]
  }
]
```

Log text is only the first filter. A candidate is not emitted until its successful transaction has been fetched and exactly one safe output mint can be resolved.

## Operational caveats

New-token trading is adversarial. A successful quote does not prove that a mint is sellable, immutable, fairly distributed, or free of Token-2022 transfer restrictions. For live use, an `ALLOW_MINTS` policy or additional mint-authority, freeze-authority, token-extension, liquidity-lock, and holder-concentration checks should be added for the intended strategy. Keep `DRY_RUN=true` until observed events and quote behavior match expectations.
