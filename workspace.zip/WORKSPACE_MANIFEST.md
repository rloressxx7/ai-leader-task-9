# Arena workspace handoff
This archive is a current snapshot of the shared task workspace.
Build on these files and return only complete files that must change.

## Included files
- README.md
- package-lock.json
- package.json
- tsconfig.json
- artifacts/step-1-arena-1-research.md
- src/cli.ts
- src/detector.ts
- src/engine.ts
- src/logger.ts
- src/risk.ts
- src/rpc.ts
- src/types.ts
- test/helpers.ts

## Omitted by safety/size policy
- .env.example
- .git
- .gitignore
- src/config.ts
- src/jupiter.ts
- test/detector.test.ts
- test/jupiter.test.ts
- test/risk.test.ts
